const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const path = require("path");

const app = express();
const PORT = 3000;

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.static(__dirname)); // serve HTML

// =====================
// MongoDB Connection (Fixed)
// =====================
mongoose.connect("mongodb://127.0.0.1:27017/hospital")
  .then(() => console.log("MongoDB Connected ✅"))
  .catch(err => console.log("Mongo Error:", err));


// =====================
// Appointment Schema
// =====================
const appointmentSchema = new mongoose.Schema({
  doctor: { type: String, required: true },
  patient: { type: String, required: true },
  phone: { type: String, required: true },
  date: { type: String, required: true },
  time: { type: String, required: true },
  problem: { type: String, required: true }
});

const Appointment = mongoose.model("Appointment", appointmentSchema);


// =====================
// Home Route
// =====================
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "Hospital.html"));
});


// =====================
// Create Appointment API
// =====================
app.post("/api/appointments", async (req, res) => {
  try {

    console.log("Incoming Data:", req.body);

    const { doctor, patient, phone, date, time, problem } = req.body;

    if (!doctor || !patient || !phone || !date || !time || !problem) {
      return res.status(400).json({ error: "All fields are required ❌" });
    }

    const newAppointment = new Appointment({
      doctor,
      patient,
      phone,
      date,
      time,
      problem
    });

    await newAppointment.save();

    res.json({ message: "Appointment Saved ✅" });

  } catch (error) {
    console.log("Server Error:", error);
    res.status(500).json({ error: error.message });
  }
});


// =====================
app.listen(PORT, () => {
  console.log(`Server Running on http://localhost:${PORT}`);
});